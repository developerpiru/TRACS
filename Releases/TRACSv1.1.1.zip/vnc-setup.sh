#!/bin/bash

#This script will setup your headless server with a desktop interface you can remotely connect to so that you can run the TRACS graphical interface
#Created February 2020

echo "Updating libraries..."
sudo apt-get update -y
echo "Installing VNC components..."
sudo apt-get install xfce4 xfce4-goodies tightvncserver -y
echo "Starting VNC server..."
vncserver
echo "Killing VNC server..."
vncserver -kill :1
echo "Configuring VNC startup..."
sudo cp xstartup ~/.vnc/xstartup
sudo chmod +x ~/.vnc/xstartup
echo "All done!"
echo "The VNC server has now been installed! You can start it using: vncserver -geometry 1200x1050"
echo "Install a VNC client (PuTTY or VNC Viewer) on your local computer to connect to the server."