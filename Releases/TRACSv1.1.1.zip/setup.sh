#!/bin/bash

#This script will install the required components for TRACS
#Created February 2020
#For TRACS version v1.1.1

echo "Updating libraries..."
sudo apt-get update -y
echo "Installing required components..."
sudo apt-get install python3 python3-tk python3-pandas python3-scipy python3-numpy cutadapt bowtie2 samtools python3-distutils python3-dev build-essential  -y
echo "Configuring mageck..."
tar xvf mageck-0.5.5.tar.gz
cd mageck-0.5.5
sudo python setup.py install -y
echo "All done!"
echo "You can run TRACS by entering: python3 TRACS.py
