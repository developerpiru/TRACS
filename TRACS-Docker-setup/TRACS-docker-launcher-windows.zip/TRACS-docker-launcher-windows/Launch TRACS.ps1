﻿start "config.xlaunch"

echo "Starting a new docker container with TRACS..."

$env:HostIP = (
    Get-NetIPConfiguration |
    Where-Object {
        $_.IPv4DefaultGateway -ne $null -and
        $_.NetAdapter.Status -ne "Disconnected"
    }
).IPv4Address.IPAddress

$IPport = -join($env:HostIP,":0.0")

set-variable -name DISPLAY -value $IPport

docker run -ti --rm -e DISPLAY=$DISPLAY -v c:\:/app/TRACS/cdrive/ pirunthan/tracs:latest