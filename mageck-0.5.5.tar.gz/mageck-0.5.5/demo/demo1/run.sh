#!/bin/bash


mageck test -k sample.txt -t HL60.final,KBM7.final -c HL60.initial,KBM7.initial  -n demo
# or
#mageck test -k sample.txt -t 2,3 -c 0,1  -n demo

    
